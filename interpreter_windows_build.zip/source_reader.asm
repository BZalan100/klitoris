%ifndef SOURCE_READER_ASM
%define SOURCE_READER_ASM

%define SOURCE_CAPACITY 1048576
%define SOURCE_EOF      256

%define GENERIC_READ          0x80000000
%define FILE_SHARE_READ       0x00000001
%define OPEN_EXISTING         3
%define FILE_ATTRIBUTE_NORMAL 0x00000080
%define INVALID_HANDLE_VALUE  -1

extern CreateFileA
extern ReadFile
extern CloseHandle

; PROCESS_SOURCE filename_label, handler_label
%macro PROCESS_SOURCE 2
    lea rdi, [rel %1]
    lea rsi, [rel %2]
    call source_for_each
%endmacro

section .bss
    source_buffer:     resb SOURCE_CAPACITY + 1
    source_length:     resq 1
    source_position:   resq 1
    source_handle:     resq 1
    source_callback:   resq 1
    source_bytes_read: resd 1

section .text

; Internal calling convention kept from the Linux version:
;   rdi = filename
; returns:
;   rax = 0 on success
;   rax < 0 on error
source_load:
    push r12
    xor r12d, r12d

    ; HANDLE CreateFileA(
    ;   filename, GENERIC_READ, FILE_SHARE_READ, NULL,
    ;   OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL)
    ;
    ; Windows x64 ABI: rcx, rdx, r8, r9, then stack args.
    ; 32 bytes of shadow space are mandatory.
    sub rsp, 64
    mov rcx, rdi
    mov edx, GENERIC_READ
    mov r8d, FILE_SHARE_READ
    xor r9d, r9d
    mov qword [rsp + 32], OPEN_EXISTING
    mov qword [rsp + 40], FILE_ATTRIBUTE_NORMAL
    mov qword [rsp + 48], 0
    call CreateFileA
    add rsp, 64

    cmp rax, INVALID_HANDLE_VALUE
    je .open_error

    mov [rel source_handle], rax

.read_more:
    cmp r12, SOURCE_CAPACITY + 1
    jae .too_large

    lea rdx, [rel source_buffer]
    add rdx, r12

    mov r8d, SOURCE_CAPACITY + 1
    sub r8, r12

    ; BOOL ReadFile(handle, buffer, count, &bytes_read, NULL)
    sub rsp, 48
    mov rcx, [rel source_handle]
    lea r9, [rel source_bytes_read]
    mov qword [rsp + 32], 0
    call ReadFile
    add rsp, 48

    test eax, eax
    jz .read_error

    mov eax, [rel source_bytes_read]
    test eax, eax
    jz .loaded

    add r12, rax
    jmp .read_more

.loaded:
    cmp r12, SOURCE_CAPACITY
    ja .too_large

    mov [rel source_length], r12
    mov qword [rel source_position], 0

    sub rsp, 32
    mov rcx, [rel source_handle]
    call CloseHandle
    add rsp, 32

    xor eax, eax
    pop r12
    ret

.read_error:
    sub rsp, 32
    mov rcx, [rel source_handle]
    call CloseHandle
    add rsp, 32

    mov rax, -5
    pop r12
    ret

.too_large:
    sub rsp, 32
    mov rcx, [rel source_handle]
    call CloseHandle
    add rsp, 32

    mov rax, -27
    pop r12
    ret

.open_error:
    mov rax, -2
    pop r12
    ret

; Returns:
;   rax = 0..255 for a character
;   rax = SOURCE_EOF at the end
source_next:
    mov rdx, [rel source_position]
    cmp rdx, [rel source_length]
    jae .end

    lea rcx, [rel source_buffer]
    movzx eax, byte [rcx + rdx]

    inc rdx
    mov [rel source_position], rdx
    ret

.end:
    mov eax, SOURCE_EOF
    ret

; Returns the next character without advancing.
source_peek:
    mov rdx, [rel source_position]
    cmp rdx, [rel source_length]
    jae .end

    lea rcx, [rel source_buffer]
    movzx eax, byte [rcx + rdx]
    ret

.end:
    mov eax, SOURCE_EOF
    ret

; Returns the current position.
source_get_position:
    mov rax, [rel source_position]
    ret

; rdi = new position
; returns 0 on success, negative on invalid position
source_set_position:
    cmp rdi, [rel source_length]
    ja .invalid

    mov [rel source_position], rdi
    xor eax, eax
    ret

.invalid:
    mov rax, -22
    ret

source_reset:
    mov qword [rel source_position], 0
    ret

source_stop:
    mov rax, [rel source_length]
    mov [rel source_position], rax
    ret

; rdi = filename
; rsi = character-handler function
;
; The handler receives:
;   al  = character
;   dil = character
;
; returns 0 on success or a negative error
source_for_each:
    mov [rel source_callback], rsi

    call source_load
    test rax, rax
    js .return

.loop:
    call source_next

    cmp eax, SOURCE_EOF
    je .finished

    mov edi, eax
    call qword [rel source_callback]

    jmp .loop

.finished:
    xor eax, eax

.return:
    ret

%endif
