global read_char
global read_word
global write_stdout
global print_char
global print_uint
global print_int

%define STD_INPUT_HANDLE  -10
%define STD_OUTPUT_HANDLE -11
%define INVALID_HANDLE_VALUE -1

extern GetStdHandle
extern ReadFile
extern WriteFile

section .bss
    stdin_handle:        resq 1
    stdout_handle:       resq 1
    io_char_buffer:      resb 1
    io_bytes_transferred: resd 1

section .text

; Returns one byte in eax, or 0 on EOF/error.
read_char:
    ; Entry rsp is 8 mod 16. 40 bytes gives us:
    ;   32 bytes Win64 shadow space + one stack argument,
    ; while aligning rsp to 16 bytes before calls.
    sub rsp, 40

    mov rcx, [rel stdin_handle]
    test rcx, rcx
    jnz .have_stdin

    mov ecx, STD_INPUT_HANDLE
    call GetStdHandle
    cmp rax, INVALID_HANDLE_VALUE
    je .failure
    test rax, rax
    jz .failure

    mov [rel stdin_handle], rax
    mov rcx, rax

.have_stdin:
    ; BOOL ReadFile(stdin, &char, 1, &bytes_read, NULL)
    lea rdx, [rel io_char_buffer]
    mov r8d, 1
    lea r9, [rel io_bytes_transferred]
    mov qword [rsp + 32], 0
    call ReadFile

    test eax, eax
    jz .failure
    cmp dword [rel io_bytes_transferred], 1
    jne .failure

    movzx eax, byte [rel io_char_buffer]
    add rsp, 40
    ret

.failure:
    xor eax, eax
    add rsp, 40
    ret

read_word:
    push r12
    push r13
    push r14

    mov r12, rdi
    mov r13, rsi
    xor r14d, r14d

    test r13, r13
    jz .fail_no_buffer

.skip_whitespace:
    call read_char
    test eax, eax
    jz .eof_before_word

    cmp al, ' '
    je .skip_whitespace
    cmp al, 9
    jb .have_character
    cmp al, 13
    jbe .skip_whitespace

.have_character:
.store_loop:
    lea rcx, [r14 + 1]
    cmp rcx, r13
    jae .overflow

    mov byte [r12 + r14], al
    inc r14

    call read_char
    test eax, eax
    jz .success

    cmp al, ' '
    je .success
    cmp al, 9
    jb .store_loop
    cmp al, 13
    jbe .success
    jmp .store_loop

.overflow:
    mov byte [r12 + r14], 0

.discard_rest:
    call read_char
    test eax, eax
    jz .failure

    cmp al, ' '
    je .failure
    cmp al, 9
    jb .discard_rest
    cmp al, 13
    jbe .failure
    jmp .discard_rest

.eof_before_word:
    mov byte [r12], 0
.failure:
    xor eax, eax
    jmp .done

.fail_no_buffer:
    xor eax, eax
    jmp .done

.success:
    mov byte [r12 + r14], 0
    mov rax, r12

.done:
    pop r14
    pop r13
    pop r12
    ret

; Internal calling convention retained from Linux:
;   rsi = buffer
;   rdx = byte count
; Returns number of bytes written, or -1 on error.
write_stdout:
    push r12
    push r13
    sub rsp, 56

    mov r12, rsi
    mov r13, rdx
    mov [rsp + 40], rdx       ; original requested length

    mov rcx, [rel stdout_handle]
    test rcx, rcx
    jnz .loop

    mov ecx, STD_OUTPUT_HANDLE
    call GetStdHandle
    cmp rax, INVALID_HANDLE_VALUE
    je .error
    test rax, rax
    jz .error
    mov [rel stdout_handle], rax

.loop:
    test r13, r13
    jz .done

    ; BOOL WriteFile(stdout, buffer, count, &written, NULL)
    mov rcx, [rel stdout_handle]
    mov rdx, r12
    mov r8d, r13d
    lea r9, [rel io_bytes_transferred]
    mov qword [rsp + 32], 0
    call WriteFile

    test eax, eax
    jz .error

    mov eax, [rel io_bytes_transferred]
    test eax, eax
    jz .done

    add r12, rax
    sub r13, rax
    jmp .loop

.done:
    mov rax, [rsp + 40]
    sub rax, r13
    jmp .return

.error:
    mov rax, -1

.return:
    add rsp, 56
    pop r13
    pop r12
    ret

print_char:
    sub rsp, 8
    mov byte [rsp], dil
    mov rsi, rsp
    mov edx, 1
    call write_stdout
    add rsp, 8
    ret

print_uint:
    sub rsp, 40
    lea rsi, [rsp + 40]

    mov rax, rdi
    mov ecx, 10
    test rax, rax
    jne .convert

    dec rsi
    mov byte [rsi], '0'
    mov edx, 1
    jmp .write

.convert:
    xor edx, edx
    div rcx
    add dl, '0'
    dec rsi
    mov byte [rsi], dl
    test rax, rax
    jne .convert

    lea rdx, [rsp + 40]
    sub rdx, rsi

.write:
    call write_stdout
    add rsp, 40
    ret

print_int:
    test rdi, rdi
    jns .nonnegative

    mov rax, rdi
    neg rax
    push rax
    mov edi, '-'
    call print_char
    pop rdi

.nonnegative:
    jmp print_uint
